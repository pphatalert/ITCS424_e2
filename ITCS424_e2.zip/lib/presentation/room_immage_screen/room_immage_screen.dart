import '../room_immage_screen/widgets/roomimageslider_item_widget.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:phat/core/app_export.dart';
import 'package:phat/widgets/custom_icon_button.dart';

class RoomImmageScreen extends StatelessWidget {
  RoomImmageScreen({Key? key})
      : super(
          key: key,
        );

  int sliderIndex = 1;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: SizedBox(
          height: SizeUtils.height,
          width: double.maxFinite,
          child: Stack(
            alignment: Alignment.bottomLeft,
            children: [
              Align(
                alignment: Alignment.center,
                child: Container(
                  width: double.maxFinite,
                  padding: EdgeInsets.symmetric(
                    horizontal: 29.h,
                    vertical: 39.v,
                  ),
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      image: AssetImage(
                        ImageConstant.imgFrame22,
                      ),
                      fit: BoxFit.cover,
                    ),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: EdgeInsets.only(bottom: 815.v),
                        child: CustomIconButton(
                          height: 39.v,
                          width: 40.h,
                          padding: EdgeInsets.all(10.h),
                          child: CustomImageView(
                            imagePath: ImageConstant.imgFrame2,
                          ),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(bottom: 815.v),
                        child: CustomIconButton(
                          height: 39.v,
                          width: 40.h,
                          padding: EdgeInsets.all(8.h),
                          child: CustomImageView(
                            imagePath: ImageConstant.imgFrame17,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              _buildRoomImageSlider(context),
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildRoomImageSlider(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(bottom: 60.v),
      child: CarouselSlider.builder(
        options: CarouselOptions(
          height: 103.v,
          initialPage: 0,
          autoPlay: true,
          viewportFraction: 1.0,
          enableInfiniteScroll: false,
          scrollDirection: Axis.horizontal,
          onPageChanged: (
            index,
            reason,
          ) {
            sliderIndex = index;
          },
        ),
        itemCount: 3,
        itemBuilder: (context, index, realIndex) {
          return RoomimagesliderItemWidget();
        },
      ),
    );
  }
}
