import 'package:flutter/material.dart';
import 'package:phat/presentation/room_immage_screen/room_immage_screen.dart';

class AppRoutes {
  static const String roomImmageScreen = '/room_immage_screen';

  static Map<String, WidgetBuilder> routes = {
    roomImmageScreen: (context) => RoomImmageScreen()
  };
}
