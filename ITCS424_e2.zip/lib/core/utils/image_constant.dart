class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

  // Room Immage images
  static String imgFrame22 = '$imagePath/img_frame_22.png';

  static String imgFrame2 = '$imagePath/img_frame_2.png';

  static String imgFrame17 = '$imagePath/img_frame_17.png';

  static String imgImage1 = '$imagePath/img_image_1.png';

  static String imgTelevision = '$imagePath/img_television.png';

  static String imgImage183x83 = '$imagePath/img_image_1_83x83.png';

  static String imgUser = '$imagePath/img_user.png';

  static String imgImage11 = '$imagePath/img_image_1_1.png';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
